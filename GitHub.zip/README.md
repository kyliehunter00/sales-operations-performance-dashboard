# Sales Operations Performance Dashboard

**Portfolio project | Excel | Sales operations analytics**

> **Data disclosure:** This is an independent educational project built using a fully synthetic dataset. The transactions, account owners, products, targets, and results are fictional. No confidential employer or customer data is included.

## Business problem

An operations team needs a consistent way to review sales attainment, track monthly revenue against targets, and identify areas for follow-up. This workbook combines raw transactions, business rules, performance targets, and dashboard reporting in one place.

## Project files

- `Sales_Operations_Portfolio_Dashboard.xlsx` — interactive Excel workbook with Dashboard, Sales Data, Targets, and Start Here sheets.
- `sample_sales_transactions.csv` — a portable sample of the synthetic source records.

## Key questions

1. Did total sales revenue meet the six-month target?
2. Which months were above or below target?
3. What proportion of transactions were refunded?
4. How was net revenue distributed by region?

## Tools and methods

- **Microsoft Excel:** SUMIF, COUNTIF, IF, IFERROR, calculated fields, conditional formatting, and a revenue-versus-target chart.
- **Data modeling:** Separate raw transactions, monthly targets, and output dashboard.
- **Operational metric definitions:** Net revenue equals gross revenue for `Closed Won` transactions and zero for `Refunded` transactions. *This is a simplified teaching convention, not a general accounting treatment of refunds.*

## Example findings (synthetic data)

| Metric | Result |
|---|---:|
| Total net revenue | $166,622.81 |
| Six-month target | $164,500.00 |
| Target attainment | 101.3% |
| Above-target months | February, March, May, June |
| Below-target months | January, April |
| Largest monthly revenue shortfall | April: -$9,156.60 |
| Largest monthly revenue surplus | February: +$6,784.56 |

## Suggested operational recommendations

1. Investigate why April showed the largest shortfall versus target, with attention to conversion trends, order rejections, and reporting completeness.
2. Review what differed in February and June to determine whether successful practices could be standardized.
3. Introduce a recurring CRM data-quality and reporting check before monthly business reviews.
4. Track refund and rejected-order reasons separately in a future version of the model.

**Important:** These are proposed investigation steps, not causal conclusions. The synthetic dataset does not contain enough detail to establish why a particular month underperformed.

## How to explore the workbook

1. Open the workbook in Microsoft Excel.
2. Review the **Start Here** sheet, then open **Dashboard**.
3. Inspect **Sales Data** to understand which transactions count in net revenue.
4. Change monthly targets in **Targets**, or make changes to fictional transactions, to see how the formulas affect the metrics.
5. Before describing this as your personal project, reproduce the calculations, verify the findings, and write your own explanation of what you learned.

## Ideas for version 2

- Create an account-level analysis with de-duplication and CRM data-validation checks.
- Add an order rejection / remediation log and SLA tracking.
- Build a Power BI visualization from the synthetic transactions.
- Write SQL queries for monthly revenue, region contribution, and attainment.

## Interview discussion prompt

“I practiced building a sales operations dashboard from synthetic transaction data. I separated raw data from targets, used Excel formulas to calculate revenue and attainment, and reviewed monthly variances to propose operational follow-up questions.”

Only use this description after you have worked through the project and can comfortably explain the formulas and findings.
